package graphics;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import datastructures.LinkedListStack;

public class FractalTreePanel extends JPanel {

    public FractalTreePanel() {
        // Set the preferred size of the panel (for example, 800x600)
        setPreferredSize(new Dimension(800, 600));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawTree(g);
    }

    private void drawTree(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        // TODO: Implement the iterative fractal tree drawing using LinkedListStack
        // 1. Initialize the stack with the base state of the tree (e.g., trunk position, length, and angle)
        // 2. Use a loop to **iteratively process** each element in the stack:
        //    a. Draw the current branch.
        //    b. Calculate and push new branches based on the current state.
        // 3. Continue until the stack is empty or a maximum depth is reached.

        // TODO: placeholder - comment this out later.
        // For now, as a placeholder, we draw a circle at the center of the panel.
        // This is to demonstrate a simple drawing operation. Replace this with the actual tree drawing logic.
        drawCircle(g, getWidth() / 2, getHeight() / 2, 50);
    }


    // TODO: circle place holder =
    private void drawCircle(Graphics g, int x, int y, int radius) {
        // Placeholder for drawing a simple circle
        g.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);
    }
}
